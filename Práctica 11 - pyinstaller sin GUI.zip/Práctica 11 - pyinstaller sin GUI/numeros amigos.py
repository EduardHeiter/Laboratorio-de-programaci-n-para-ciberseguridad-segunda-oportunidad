"""
Alumno: Eduardo Alonso Gaytan Valadez       Grupo: 063
Profesor: Jose Anastacio Hernández
Práctica # 11 - Pyinstaller con interfaz gráfica

Código para determinar el numero insertado tiene un numero amigo, es decir, si la suma de los divisores propios de un numero es igual al otro y viceversa.
Ejemplo: el 220 y 284
---> los divisores propios de 220 son 1, 2, 4, 5, 10, 11, 20, 22, 44, 55 y 110, que suman 284;
---> los divisores propios de 284 son 1, 2, 4, 71 y 142, que suman 220.

"""

while True:
	
	n = int(input("Inserta un numero que tenga numero amigo: "))
	m,c = 0, 0
	
	for i in range(1,n-1,1):
		if ((n%i) == 0):
			m += i
	
	for i in range(1,m-1,1):
		if ((m%i) == 0):
			c += i


	if c == n :
		print(str(n) + " y " + str(m) + " son numeros amigos")
		input()
		break;

	print("Intente otro número, ya que el que insertó no tiene amigos.")	 